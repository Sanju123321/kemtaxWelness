

<?php $__env->startSection('title', 'Our Services'); ?>
<?php $__env->startSection('meta_description', 'Explore the wellness services offered by KemtexWellness.'); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="py-5 bg-success text-white">
        <div class="container text-center">
            <h1 class="fw-bold">Our Services</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white-75">Home</a></li>
                    <li class="breadcrumb-item active text-white" aria-current="page">Services</li>
                </ol>
            </nav>
        </div>
    </section>

    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <?php
                    $services = [
                        [
                            'icon' => 'person-heart',
                            'title' => 'Wellness Consulting',
                            'desc' =>
                                'One-on-one sessions with certified wellness consultants tailored to your health goals.',
                            'color' => 'success',
                        ],
                        [
                            'icon' => 'journal-medical',
                            'title' => 'Nutrition Planning',
                            'desc' => 'Personalised meal and supplement plans designed by registered dietitians.',
                            'color' => 'primary',
                        ],
                        [
                            'icon' => 'activity',
                            'title' => 'Health Assessments',
                            'desc' => 'Comprehensive wellness assessments to understand your current health status.',
                            'color' => 'warning',
                        ],
                        [
                            'icon' => 'camera-video',
                            'title' => 'Virtual Workshops',
                            'desc' => 'Live online workshops covering fitness, nutrition, mental well-being, and more.',
                            'color' => 'info',
                        ],
                        [
                            'icon' => 'truck',
                            'title' => 'Subscription Boxes',
                            'desc' => 'Curated monthly wellness boxes delivered straight to your door.',
                            'color' => 'danger',
                        ],
                        [
                            'icon' => 'headset',
                            'title' => '24/7 Support',
                            'desc' => 'Round-the-clock support from our team of wellness experts.',
                            'color' => 'secondary',
                        ],
                    ];
                ?>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card border-0 shadow-sm h-100 text-center p-4">
                            <div class="rounded-circle bg-<?php echo e($s['color']); ?> bg-opacity-10 mx-auto mb-4 d-flex align-items-center justify-content-center"
                                style="width:72px;height:72px;">
                                <i class="bi bi-<?php echo e($s['icon']); ?> fs-2 text-<?php echo e($s['color']); ?>"></i>
                            </div>
                            <h5 class="fw-bold"><?php echo e($s['title']); ?></h5>
                            <p class="text-muted small"><?php echo e($s['desc']); ?></p>
                            <a href="<?php echo e(route('contact')); ?>"
                                class="btn btn-sm btn-outline-<?php echo e($s['color']); ?> mt-auto">Learn More</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kemtexWellness\resources\views/frontend/services/index.blade.php ENDPATH**/ ?>