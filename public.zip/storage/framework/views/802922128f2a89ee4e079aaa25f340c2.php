<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'KemtexWellness Admin Panel'); ?>" />
    <meta name="author" content="KemtexWellness" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | KemtexWellness Admin</title>

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />

    
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet" />

    
    <link href="<?php echo e(asset('backend/css/styles.css')); ?>" rel="stylesheet" />

    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="sb-nav-fixed">

    
    <?php echo $__env->make('backend.layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div id="layoutSidenav">

        
        <?php echo $__env->make('backend.layouts.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">

                    
                    <h1 class="mt-4"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></h1>

                    
                    <?php if (! empty(trim($__env->yieldContent('breadcrumb')))): ?>
                        <ol class="breadcrumb mb-4">
                            <?php echo $__env->yieldContent('breadcrumb'); ?>
                        </ol>
                    <?php endif; ?>

                    
                    <?php echo $__env->make('backend.layouts.partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    
                    <?php echo $__env->yieldContent('content'); ?>

                </div>
            </main>

            
            <?php echo $__env->make('backend.layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    
    <script src="<?php echo e(asset('backend/js/scripts.js')); ?>"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\kemtexWellness\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>