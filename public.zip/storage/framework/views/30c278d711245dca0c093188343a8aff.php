<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'KemtexWellness - Natural Health & Wellness Products'); ?>" />
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', 'wellness, health, supplements, herbal, natural'); ?>" />
    <meta name="author" content="KemtexWellness" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'KemtexWellness'); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description', 'Natural Health & Wellness Products'); ?>" />
    <meta property="og:type" content="website" />

    <title><?php echo $__env->yieldContent('title', 'Welcome'); ?> | KemtexWellness</title>

    
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon" />

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />

    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />

    
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap"
        rel="stylesheet" />

    
    <link href="<?php echo e(asset('frontend/css/styles.css')); ?>" rel="stylesheet" />

    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

    
    <div class="bg-dark text-white py-1 d-none d-md-block">
        <div class="container d-flex justify-content-between align-items-center small">
            <div>
                <i class="bi bi-telephone me-1"></i> +1 800 KEMTEX &nbsp;&nbsp;
                <i class="bi bi-envelope me-1"></i> info@kemtexwellness.com
            </div>
            <div>
                <a href="#" class="text-white me-2"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-white me-2"><i class="bi bi-instagram"></i></a>
                <a href="#" class="text-white me-2"><i class="bi bi-twitter-x"></i></a>
                <a href="#" class="text-white"><i class="bi bi-linkedin"></i></a>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('frontend.layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <?php echo $__env->make('frontend.layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <button id="backToTop" class="btn btn-primary btn-sm rounded-circle shadow"
        style="position:fixed; bottom:2rem; right:2rem; display:none; width:42px; height:42px; z-index:9999;">
        <i class="bi bi-arrow-up"></i>
    </button>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    
    <script src="<?php echo e(asset('frontend/js/scripts.js')); ?>" defer></script>

    <script>
        // Back to top button
        const btn = document.getElementById('backToTop');
        window.onscroll = () => {
            btn.style.display = window.scrollY > 300 ? 'block' : 'none';
        };
        btn.addEventListener('click', () => window.scrollTo({
            top: 0,
            behavior: 'smooth'
        }));
    </script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\kemtexWellness\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>