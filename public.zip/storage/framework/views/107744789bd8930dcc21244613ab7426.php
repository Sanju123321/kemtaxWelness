<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">
                &copy; <?php echo e(date('Y')); ?> <strong>KemtexWellness</strong>. All rights reserved.
            </div>
            <div>
                <a href="#" class="text-muted text-decoration-none me-3">Privacy Policy</a>
                <a href="#" class="text-muted text-decoration-none">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\kemtexWellness\resources\views/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>