<?php $__env->startSection('title', 'Member Login - KemtexWellness'); ?>

<?php $__env->startSection('content'); ?>

    <section class="page-title bg-1">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="block text-center">
                        <span class="text-white">🔐 Member Access</span>
                        <h1 class="text-capitalize mb-4 text-lg">Welcome Back</h1>
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="<?php echo e(route('home')); ?>" class="text-white">Home</a></li>
                            <li class="list-inline-item"><span class="text-white">/</span></li>
                            <li class="list-inline-item text-white-50">Login</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section login-section py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-7">
                    <div class="login-card bg-white p-5 rounded shadow-sm">
                        <div class="login-header text-center mb-4">
                            <div class="login-icon mb-3">
                                <i class="fas fa-lock text-color" style="font-size: 3rem;"></i>
                            </div>
                            <h2 class="mb-2">Member Login</h2>
                            <p class="text-muted">Access your Kemtex Wellness account</p>
                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <div><?php echo e($error); ?></div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <form id="loginForm" class="login-form"   method="POST" action="<?php echo e(route('login.post')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group mb-4">
                                <label for="phone"><i class="fas fa-phone text-color mr-2"></i>Phone Number</label>
                                <input type="tel"
                                    class="form-control form-control-lg <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone"
                                    name="phone" placeholder="Enter your Phone Number" value="<?php echo e(old('phone')); ?>" required
                                    autofocus>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div class="form-group mb-3">
                                <label for="password"><i class="fas fa-key text-color mr-2"></i>Password</label>
                                <input type="password"
                                    class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="password" name="password" placeholder="Enter your password" required>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div class="text-right mb-4">
                                <a href="<?php echo e(route('password.request')); ?>" class="text-color font-weight-600 small">Forgot
                                    password?</a>
                            </div>

                            <div class="form-group mb-4">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="rememberMe" name="remember">
                                    <label class="custom-control-label" for="rememberMe">Remember me for 30 days</label>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-main btn-lg btn-block btn-round-full mb-3">
                                <i class="fas fa-sign-in-alt mr-2"></i>Login to Account
                            </button>

                            <div class="text-center">
                                <p class="text-muted">Don't have an account? <a href="<?php echo e(route('register')); ?>"
                                        class="text-color font-weight-600">Sign up here</a></p>
                            </div>
                        </form>
                    </div>

                    <div class="row mt-5">
                        <div class="col-md-6 mb-3">
                            <div class="info-card text-center bg-white p-4 rounded shadow-sm">
                                <i class="ti-help text-color mb-2" style="font-size: 1.8rem;"></i>
                                <h6 class="mt-2">Need Help?</h6>
                                <p class="text-muted small">Contact our support team</p>
                                <a href="<?php echo e(route('contact')); ?>" class="text-color small font-weight-600">Get Support</a>
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <div class="info-card text-center bg-white p-4 rounded shadow-sm">
                                <i class="ti-key text-color mb-2" style="font-size: 1.8rem;"></i>
                                <h6 class="mt-2">Account Issues?</h6>
                                <p class="text-muted small">Verify your credentials</p>
                                <a href="<?php echo e(route('password.request')); ?>" class="text-color small font-weight-600">Reset
                                    Password</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-2">
        <div class="container">
            <div class="cta-block p-5 rounded">
                <div class="row justify-content-center align-items-center">
                    <div class="col-lg-8 text-center">
                        <span class="text-color">🚀 New to Kemtex Wellness?</span>
                        <h2 class="mt-2 text-white mb-3">Join Our Growing Community Today</h2>
                        <p class="text-white mb-4">Start your journey to financial freedom with our proven MLM opportunity
                        </p>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-light btn-round-full">Create Your
                            Account</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>

<script>
$(document).ready(function () {

    $("#loginForm").validate({
        rules: {
            phone: {
                required: true,
                minlength: 10
            },
            password: {
                required: true,
               
            },
        },

        messages: {
          
            phone: {
                required: "Enter phone number",
                digits: "Only numbers allowed",
                minlength: "Must be 10 digits",
                maxlength: "Must be 10 digits"
            },
           
            password: {
                required: "Enter password",
                minlength: "Minimum 8 characters"
            },
           
        },

    });

    // 🔐 Password validation
    $.validator.addMethod("pwcheck", function (value) {
        return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value);
    }, "Password must contain uppercase, lowercase and number");

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kemtexWellness\resources\views/frontend/auth/login.blade.php ENDPATH**/ ?>