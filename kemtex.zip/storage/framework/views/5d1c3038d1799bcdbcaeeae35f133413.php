<?php
use Livewire\Component;
use App\Models\User;
use App\Models\UserTree;
use Illuminate\Support\Facades\Cache;
?>

<div class="genealogy-tree">
    <ul>
        <?php echo $__env->make('livewire.partials.tree', ['node' => $tree], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\kemtexWellness\storage\framework/views/livewire/views/56ac981d.blade.php ENDPATH**/ ?>