<?php
use Livewire\Component;
use App\Models\User;
use App\Models\UserTree;
use Illuminate\Support\Facades\Cache;
?>

<div class="genealogy-tree">
    <ul>
        @include('livewire.partials.tree', ['node' => $tree])
    </ul>
</div>