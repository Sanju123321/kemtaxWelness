<?php $__env->startSection('title', 'Contact Us - KemtexWellness'); ?>

<?php $__env->startSection('content'); ?>

    <section class="page-title bg-1">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="block text-center">
                        <span class="text-white">💼 Opportunity</span>
                        <h1 class="text-capitalize mb-4 text-lg">Let's Build Your Success Story</h1>
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="<?php echo e(route('home')); ?>" class="text-white">Home</a></li>
                            <li class="list-inline-item"><span class="text-white">/</span></li>
                            <li class="list-inline-item text-white-50">Join Us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Form Start -->
    <section class="contact-form-wrap section">
        <div class="container">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <form id="contact-form" class="contact__form" method="POST" action="<?php echo e(route('contact.send')); ?>">
                        <?php echo csrf_field(); ?>
                        <h3 class="text-md mb-4">🚀 Start Your Journey</h3>
                        <p class="mb-4 text-muted">Tell us about yourself and we'll guide you to the right opportunity</p>

                        <div class="form-group">
                            <input name="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Your Full Name" value="<?php echo e(old('name')); ?>" required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <input name="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Email Address" value="<?php echo e(old('email')); ?>" required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div class="form-group">
                            <input name="phone" type="text" class="form-control" placeholder="Phone Number"
                                value="<?php echo e(old('phone')); ?>">
                        </div>
                        <div class="form-group">
                            <select name="interest" class="form-control">
                                <option value="">Select Your Interest Level</option>
                                <option value="curious" <?php echo e(old('interest') == 'curious' ? 'selected' : ''); ?>>Just Curious
                                </option>
                                <option value="serious" <?php echo e(old('interest') == 'serious' ? 'selected' : ''); ?>>Serious About
                                    Income</option>
                                <option value="fulltime" <?php echo e(old('interest') == 'fulltime' ? 'selected' : ''); ?>>Looking for
                                    Full-Time Opportunity</option>
                                <option value="already" <?php echo e(old('interest') == 'already' ? 'selected' : ''); ?>>Already in MLM
                                </option>
                            </select>
                        </div>
                        <div class="form-group-2 mb-4">
                            <textarea name="message" class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"
                                placeholder="Tell us your goals or questions..."><?php echo e(old('message')); ?></textarea>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <button class="btn btn-main" name="submit" type="submit">Get Started Now</button>
                    </form>
                </div>

                <div class="col-lg-5 col-sm-12">
                    <div class="contact-content pl-lg-5 mt-5 mt-lg-0">
                        <span class="text-muted">💎 Ready to Transform Your Life?</span>
                        <h2 class="mb-5 mt-2">Fast-Track Your Success with Our Support Team</h2>

                        <ul class="address-block list-unstyled">
                            <li><i class="ti-location-pin mr-3 text-color"></i><strong>Headquarter:</strong> Mumbai, India
                            </li>
                            <li><i class="ti-email mr-3 text-color"></i><strong>Email:</strong> <a
                                    href="mailto:kemtexwellness@gmail.com">kemtexwellness@gmail.com</a></li>
                            <li><i class="ti-mobile mr-3 text-color"></i><strong>Enrollment Line:</strong> <a
                                    href="tel:+919999999999">+91-9999-999-999</a></li>
                            <li><i class="ti-time mr-3 text-color"></i><strong>Hours:</strong> Mon-Fri 10AM-8PM, Sat
                                11AM-6PM</li>
                        </ul>

                        <div class="mt-4 p-3 rounded" style="background-color:#fff3cd;">
                            <p class="mb-0"><strong>💡 Tip:</strong> Our team typically responds within 2 hours. Have your
                                questions ready!</p>
                        </div>

                        <ul class="social-icons list-inline mt-5">
                            <li class="list-inline-item"><a href="http://www.facebook.com" title="Facebook"><i
                                        class="fab fa-facebook-f"></i></a></li>
                            <li class="list-inline-item"><a href="http://www.whatsapp.com" title="WhatsApp"><i
                                        class="fab fa-whatsapp"></i></a></li>
                            <li class="list-inline-item"><a href="http://www.instagram.com" title="Instagram"><i
                                        class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="google-map">
        <div id="map" data-latitude="19.076090" data-longitude="72.877426"
            data-marker="<?php echo e(asset('frontend/images/marker.png')); ?>" data-marker-name="KemtexWellness"></div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('frontend/plugins/google-map/map.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\kemtexWellness\resources\views/frontend/contact/index.blade.php ENDPATH**/ ?>