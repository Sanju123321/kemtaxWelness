<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title', 'KemtexWellness'); ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="KemtexWellness - Build Your Wellness Empire & Earn Unlimited Income">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="theme-name" content="megakit" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/bootstrap/bootstrap.min.css')); ?>">
    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/themify/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/fontawesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/magnific-popup/magnific-popup.css')); ?>">
    <!-- Slick Slider CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/slick/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/plugins/slick/slick-theme.css')); ?>">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('frontend/images/favicon.png')); ?>" type="image/x-icon">
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

    <?php echo $__env->make('frontend.layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('frontend.layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Scroll to top -->
    <div id="scroll-to-top" class="scroll-to-top">
        <span class="icon fa fa-angle-up"></span>
    </div>

    <!-- Main jQuery -->
    <script src="<?php echo e(asset('frontend/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('frontend/plugins/bootstrap/bootstrap.min.js')); ?>"></script>
    <!-- Magnific Popup -->
    <script src="<?php echo e(asset('frontend/plugins/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
    <!-- Slick Slider -->
    <script src="<?php echo e(asset('frontend/plugins/slick/slick.min.js')); ?>"></script>
    <!-- Counterup -->
    <script src="<?php echo e(asset('frontend/plugins/counterup/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/plugins/counterup/jquery.counterup.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\kemtexWellness\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>